<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

 //Version information.
 $config['current_version'] = 'Beta 0.1 build 20130707';
