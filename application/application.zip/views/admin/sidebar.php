<div class="span2 main-menu-span">
	<div class="well nav-collapse sidebar-nav">
	<ul class="nav nav-tabs nav-stacked main-menu">
		<li class="nav-header hidden-tablet">Menu</li>
		<li>
			<a href="<?=site_url('admin/dashboard');?>" class="ajaxlink">
				<i class="icon-home"></i> <span class="hidden-tablet">Dashboard</span>
			</a>
		</li>
		<li><a href="<?=site_url('admin/config');?>" class="ajaxlink"><i class="icon-wrench"></i> System</a></li>
		<li><a href="<?=site_url('admin/post');?>" class="ajaxlink"><i class="icon-plus"></i> Post</a></li>
		<li><a href="<?=site_url('admin/edit_list');?>" class="ajaxlink"><i class="icon-edit"></i> Edit</a></li>
		<li><a href="<?=site_url('admin/profile');?>" class="ajaxlink"><i class="icon-user"></i> Profile</a></li>
		<li><a href="<?=site_url('admin/image');?>" class="ajaxlink"><i class="icon-picture"></i> Images</a></li>
		<!--
		li>a.ajaxlink[href=<?=site_url('admin/config');?>]>i.icon-wrench+{ System}
		-->
	</ul>
	</div>
</div>