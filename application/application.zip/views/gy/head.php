<link rel="stylesheet" href="<?=site_url('/css/bootstrap.min.css')?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?=site_url('/css/bootstrap-responsive.css')?>">
<link rel="stylesheet" href="<?=site_url('/css/opa-icons.css')?>">
<link rel="stylesheet" href="<?=site_url('/css/font-awesome.min.css')?>">
<link rel="stylesheet" href="<?=site_url('/css/charisma-app.css')?>">
<link rel="stylesheet" href="<?=site_url('/style.css')?>">
<style>
@font-face {
  font-family: 'FontAwesome';
  src: url('<?=site_url('/fonts/fontawesome-webfont.eot?v=3.1.0')?>');
  src: url('<?=site_url('/fonts/fontawesome-webfont.eot?#iefix&v=3.1.0')?>') format('embedded-opentype'), 
       url('<?=site_url('/fonts/fontawesome-webfont.woff?v=3.1.0')?>') format('woff'), 
       url('<?=site_url('/fonts/fontawesome-webfont.ttf?v=3.1.0')?>') format('truetype'), 
       url('<?=site_url('/fonts/fontawesome-webfont.svg#fontawesomeregular?v=3.1.0')?>') format('svg');
  font-weight: normal;
  font-style: normal;
}
</style>