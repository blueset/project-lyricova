<footer>
	<div class="container">
		<p class="muted" style="margin: 20px 0;">Project Gy, a lyric-centered web-log created by Blueset Studio together with iBe.</p>
	</div>
</footer>
<script>
	currpath = "<?=base_url()?>";
</script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="<?=site_url('js/bootstrap.min.js');?>"></script>
<script src="<?=site_url('js/jquery.masonry.min.js');?>"></script>
<!--<script src="<?=site_url('js/charisma.js');?>"></script>-->
<script src="<?=site_url('js/gy.js');?>"></script>
